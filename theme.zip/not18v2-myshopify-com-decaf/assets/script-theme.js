
$(function(){
    $("#button").click(function () {
    	$("#openclose").animate({
			width:'toggle'
		},1000);		
  });
  
  //$('.dropdown-toggle').dropdown();

	$('#formtabs a').click(function (e) {
	  e.preventDefault();
	  $(this).tab('show');
	});
    
    $("#login-btn").click(function(){
		$("#loginform").css({
			visibility:'visible',
			height:"100%"	
		});
	});
	$("#loginform .close").click(function(){
		$("#loginform").css({
			visibility:'hidden',
			height:0	
		});
	});
	
	var delay = 2000,
		transition = 3000,
		total_el = i = 3;

	function animate(el){
		$(".slideshow li:nth-child("+el+") span").animate({
			opacity:'1'
		},
		transition,
		function(){
			setTimeout(function(){
				$(".slideshow li:nth-child("+el+") span").animate({
					opacity:'0'
				},
				transition);
				i--;
				//console.log("i:"+i)
				if(i<1){
					i=3;
					//console.log("Back to three.");
				}
				animate(i);
			},
			delay);
		});
	}
	animate(3);
});


